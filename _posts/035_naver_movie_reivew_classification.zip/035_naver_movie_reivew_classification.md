# 035. 네이버 영화평 감성 분류

- 한글 형태소 분석기 Okt 사용 전처리  

- Keras Tokenizer, pad_sequences 함수 사용


```python
!pip install -q KoNLPy
```

    [K     |████████████████████████████████| 19.4 MB 4.3 MB/s 
    [K     |████████████████████████████████| 448 kB 56.3 MB/s 
    [?25h


```python
import numpy as np
import pandas as pd
import re
import time
import matplotlib.pyplot as plt

from konlpy.tag import Okt
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, Bidirectional, Dense, LSTM
```


```python
DATA_TRAIN_PATH = tf.keras.utils.get_file("ratings_train.txt", 
                        "https://github.com/ironmanciti/NLP_lecture/raw/master/data/naver_movie/ratings_train.txt")
DATA_TEST_PATH = tf.keras.utils.get_file("ratings_test.txt", 
                        "https://github.com/ironmanciti/NLP_lecture/raw/master/data/naver_movie/ratings_test.txt")
```


```python
train_data = pd.read_csv(DATA_TRAIN_PATH, delimiter='\t')
print(train_data.shape)
train_data.head()
```

    (150000, 3)
    





  <div id="df-7ea4b0f0-2408-432d-a7f5-990abcbbcd75">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>document</th>
      <th>label</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9976970</td>
      <td>아 더빙.. 진짜 짜증나네요 목소리</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3819312</td>
      <td>흠...포스터보고 초딩영화줄....오버연기조차 가볍지 않구나</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10265843</td>
      <td>너무재밓었다그래서보는것을추천한다</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9045019</td>
      <td>교도소 이야기구먼 ..솔직히 재미는 없다..평점 조정</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6483659</td>
      <td>사이몬페그의 익살스런 연기가 돋보였던 영화!스파이더맨에서 늙어보이기만 했던 커스틴 ...</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-7ea4b0f0-2408-432d-a7f5-990abcbbcd75')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-7ea4b0f0-2408-432d-a7f5-990abcbbcd75 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-7ea4b0f0-2408-432d-a7f5-990abcbbcd75');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
test_data = pd.read_csv(DATA_TEST_PATH, delimiter='\t')
print(test_data.shape)
test_data.head()
```

    (50000, 3)
    





  <div id="df-4f9e4750-38d8-42db-b58a-146f27242962">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>document</th>
      <th>label</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6270596</td>
      <td>굳 ㅋ</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9274899</td>
      <td>GDNTOPCLASSINTHECLUB</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8544678</td>
      <td>뭐야 이 평점들은.... 나쁘진 않지만 10점 짜리는 더더욱 아니잖아</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6825595</td>
      <td>지루하지는 않은데 완전 막장임... 돈주고 보기에는....</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6723715</td>
      <td>3D만 아니었어도 별 다섯 개 줬을텐데.. 왜 3D로 나와서 제 심기를 불편하게 하죠??</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-4f9e4750-38d8-42db-b58a-146f27242962')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-4f9e4750-38d8-42db-b58a-146f27242962 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-4f9e4750-38d8-42db-b58a-146f27242962');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>




### 훈련 시간을 감안하여 data size 축소


```python
train_data = train_data.sample(n=50000, random_state=1)
test_data = test_data.sample(n=5000, random_state=1)

print(train_data.shape)
print(test_data.shape)
```

    (50000, 3)
    (5000, 3)
    

**null value 제거**


```python
train_data.dropna(inplace=True)

test_data.dropna(inplace=True)
```


```python
train_data.isnull().sum(), test_data.isnull().sum()
```




    (id          0
     document    0
     label       0
     dtype: int64, id          0
     document    0
     label       0
     dtype: int64)



### okt.morphs()

- 텍스트를 형태소 단위로 나눈다. 옵션으로는 norm과 stem이 있다 
- stem은 각 단어에서 어간을 추출하는 기능


```python
okt = Okt()
test = "아버지가방에들어가신다"
okt.morphs(test, stem=True)
```




    ['아버지', '가방', '에', '들어가다']



## Text Data 전처리

**한글 문자가 아닌 것 모두 제거**


```python
def preprocessing(sentence, remove_stopwords=True):
    # 불용어 제거
    #stop_words = set(['에', '은', '는', '이', '가', '그리고', '것', '들', '수', '등', '로', '을', '를', '만', '도', '아', '의', '그', '다'])
    stop_words = []
    
    sentence = re.sub('\\\\n', ' ', sentence)              # 개행문자 제거
    sentence = re.sub('[^가-힣ㄱ-ㅎㅏ-ㅣ ]', '', sentence)  #한글외에 모두 제거
    sentence = okt.morphs(sentence, stem=True)
    if remove_stopwords:
        sentence = [token for token in sentence if not token in stop_words]
    return sentence
```


```python
%%time
train_sentences = []
train_labels = []
test_sentences = []
test_labels = []

start = time.time()

for i, (sent, label) in enumerate(zip(train_data['document'], train_data['label'])):
    if i % 10000 == 0:
        print(f"Train processed = {i}")
    sent = preprocessing(sent)
    if len(sent) > 0:
        train_sentences.append(sent)
        train_labels.append(label)

for i, (sent, label) in enumerate(zip(test_data['document'], test_data['label'])):
    if i % 1000 == 0:
        print(f"Test processed = {i}")
    sent = preprocessing(sent)
    if len(sent) > 0:
        test_sentences.append(sent)
        test_labels.append(label)
    
print(time.time() - start)
```

    Train processed = 0
    Train processed = 10000
    Train processed = 20000
    Train processed = 30000
    Train processed = 40000
    Test processed = 0
    Test processed = 1000
    Test processed = 2000
    Test processed = 3000
    Test processed = 4000
    224.48733353614807
    CPU times: user 3min 48s, sys: 730 ms, total: 3min 49s
    Wall time: 3min 44s
    

## train_labels, test_labels  list를 numpy array 로 변환


```python
train_labels = np.array(train_labels)
test_labels = np.array(test_labels)

print(train_labels.shape)
print(test_labels.shape)
```

    (49571,)
    (4951,)
    

## train_sentences, test_sentences text 를 sequence 로 변환 


```python
VOCAB_SIZE = 20000

tokenizer = Tokenizer(num_words=VOCAB_SIZE, oov_token="<OOV>")
tokenizer.fit_on_texts(train_sentences)

train_sequences = tokenizer.texts_to_sequences(train_sentences)
test_sequences = tokenizer.texts_to_sequences(test_sentences)

print(train_sequences[0])
print(test_sequences[0])
```

    [90, 1370, 13, 1554, 80, 520, 8870, 14637, 29, 250, 5, 3884, 16, 430, 62, 210, 30, 1612, 14, 744, 22, 229, 6, 1123, 13, 31, 43, 12, 149, 2547, 5, 741, 12, 1554, 14638, 6007, 8871, 8872, 8, 31]
    [1683, 7, 460, 1491, 106, 346, 37, 2485, 344, 760, 206, 650, 96, 270]
    


```python
plt.hist([len(s) for s in train_sequences] + [len(s) for s in test_sequences], bins=30);
```


![png](output_20_0.png)



```python
max_length = 15

train_padded = pad_sequences(train_sequences, maxlen=max_length, padding='post', truncating='post')

test_padded = pad_sequences(test_sequences, maxlen=max_length, padding='post', truncating='post')

print(train_padded.shape)
print(test_padded.shape)
print(train_padded[0])
print(test_padded[0])
```

    (49571, 15)
    (4951, 15)
    [   90  1370    13  1554    80   520  8870 14637    29   250     5  3884
        16   430    62]
    [1683    7  460 1491  106  346   37 2485  344  760  206  650   96  270
        0]
    

### sequence 를 다시 문장으로 역변환


```python
reverse_word_index = dict([(v, k) for (k, v) in tokenizer.word_index.items()])

def decode_sentence(sequence):
    return ' '.join([reverse_word_index.get(i, '?') for i in sequence])

print(decode_sentence(train_padded[4]))
print()
print(train_sentences[4])
```

    우리나라 용가리 가 배다 더 자다 만들다 이렇다 류 영화 도 개봉 을 하나 보다
    
    ['우리나라', '용가리', '가', '배다', '더', '자다', '만들다', '이렇다', '류', '영화', '도', '개봉', '을', '하나', '보다']
    


```python
model = Sequential([
    Embedding(VOCAB_SIZE+1, 64),
    Bidirectional(LSTM(64)),
    Dense(32, activation='relu'),
    Dense(1, activation='sigmoid')
])

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
model.summary()
```

    Model: "sequential_1"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     embedding_1 (Embedding)     (None, None, 64)          1280064   
                                                                     
     bidirectional_1 (Bidirectio  (None, 128)              66048     
     nal)                                                            
                                                                     
     dense_2 (Dense)             (None, 32)                4128      
                                                                     
     dense_3 (Dense)             (None, 1)                 33        
                                                                     
    =================================================================
    Total params: 1,350,273
    Trainable params: 1,350,273
    Non-trainable params: 0
    _________________________________________________________________
    


```python
num_epochs = 30
history = model.fit(train_padded, train_labels, epochs=num_epochs, batch_size=128, 
                    validation_data=(test_padded, test_labels), verbose=1)
```

    Epoch 1/30
    388/388 [==============================] - 14s 10ms/step - loss: 0.4509 - accuracy: 0.7802 - val_loss: 0.4036 - val_accuracy: 0.8162
    Epoch 2/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.3296 - accuracy: 0.8582 - val_loss: 0.4126 - val_accuracy: 0.8140
    Epoch 3/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.2716 - accuracy: 0.8854 - val_loss: 0.4619 - val_accuracy: 0.8164
    Epoch 4/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.2225 - accuracy: 0.9056 - val_loss: 0.5133 - val_accuracy: 0.8124
    Epoch 5/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.1856 - accuracy: 0.9215 - val_loss: 0.5533 - val_accuracy: 0.8083
    Epoch 6/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.1570 - accuracy: 0.9335 - val_loss: 0.6383 - val_accuracy: 0.8057
    Epoch 7/30
    388/388 [==============================] - 3s 6ms/step - loss: 0.1355 - accuracy: 0.9444 - val_loss: 0.7165 - val_accuracy: 0.8021
    Epoch 8/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.1170 - accuracy: 0.9529 - val_loss: 0.7384 - val_accuracy: 0.7986
    Epoch 9/30
    388/388 [==============================] - 3s 8ms/step - loss: 0.1012 - accuracy: 0.9591 - val_loss: 0.7817 - val_accuracy: 0.8008
    Epoch 10/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0859 - accuracy: 0.9669 - val_loss: 0.8913 - val_accuracy: 0.7994
    Epoch 11/30
    388/388 [==============================] - 3s 8ms/step - loss: 0.0744 - accuracy: 0.9723 - val_loss: 0.8997 - val_accuracy: 0.8019
    Epoch 12/30
    388/388 [==============================] - 3s 8ms/step - loss: 0.0667 - accuracy: 0.9752 - val_loss: 0.9643 - val_accuracy: 0.7974
    Epoch 13/30
    388/388 [==============================] - 3s 8ms/step - loss: 0.0620 - accuracy: 0.9763 - val_loss: 1.0682 - val_accuracy: 0.7960
    Epoch 14/30
    388/388 [==============================] - 3s 8ms/step - loss: 0.0557 - accuracy: 0.9790 - val_loss: 1.0916 - val_accuracy: 0.7897
    Epoch 15/30
    388/388 [==============================] - 3s 6ms/step - loss: 0.0520 - accuracy: 0.9806 - val_loss: 1.1903 - val_accuracy: 0.7974
    Epoch 16/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0489 - accuracy: 0.9815 - val_loss: 1.2101 - val_accuracy: 0.7966
    Epoch 17/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0419 - accuracy: 0.9841 - val_loss: 1.2494 - val_accuracy: 0.7875
    Epoch 18/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0429 - accuracy: 0.9836 - val_loss: 1.2662 - val_accuracy: 0.7930
    Epoch 19/30
    388/388 [==============================] - 3s 6ms/step - loss: 0.0387 - accuracy: 0.9857 - val_loss: 1.3121 - val_accuracy: 0.7903
    Epoch 20/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0366 - accuracy: 0.9859 - val_loss: 1.3356 - val_accuracy: 0.7966
    Epoch 21/30
    388/388 [==============================] - 3s 6ms/step - loss: 0.0356 - accuracy: 0.9867 - val_loss: 1.3839 - val_accuracy: 0.7966
    Epoch 22/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0325 - accuracy: 0.9876 - val_loss: 1.4580 - val_accuracy: 0.7980
    Epoch 23/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0300 - accuracy: 0.9880 - val_loss: 1.5688 - val_accuracy: 0.7926
    Epoch 24/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0286 - accuracy: 0.9889 - val_loss: 1.5114 - val_accuracy: 0.7978
    Epoch 25/30
    388/388 [==============================] - 3s 8ms/step - loss: 0.0282 - accuracy: 0.9893 - val_loss: 1.5107 - val_accuracy: 0.7926
    Epoch 26/30
    388/388 [==============================] - 4s 9ms/step - loss: 0.0260 - accuracy: 0.9901 - val_loss: 1.5385 - val_accuracy: 0.8013
    Epoch 27/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0263 - accuracy: 0.9897 - val_loss: 1.6006 - val_accuracy: 0.7972
    Epoch 28/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0244 - accuracy: 0.9903 - val_loss: 1.6532 - val_accuracy: 0.8008
    Epoch 29/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0227 - accuracy: 0.9909 - val_loss: 1.6760 - val_accuracy: 0.7914
    Epoch 30/30
    388/388 [==============================] - 3s 7ms/step - loss: 0.0199 - accuracy: 0.9919 - val_loss: 1.8241 - val_accuracy: 0.7924
    


```python
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))

ax1.plot(history.history['accuracy'])
ax1.plot(history.history['val_accuracy'])
ax1.set_xlabel('Epochs')
ax1.set_ylabel('accuracy')
ax1.legend(['accuarcy', 'val_accuracy'])

ax2.plot(history.history['loss'])
ax2.plot(history.history['val_loss'])
ax2.set_xlabel('Epochs')
ax2.set_ylabel('loss')
ax2.legend(['loss', 'val_loss'])
plt.show()
```


![png](output_26_0.png)



```python
test_data.head()
```





  <div id="df-3cf8f976-09aa-404c-bf52-910d07330808">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>document</th>
      <th>label</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>26247</th>
      <td>5933705</td>
      <td>크리스마스에 어울리는 시원한 액션. 긴장감과 박진감 넘치는 전개 엄청난 마지막부분</td>
      <td>1</td>
    </tr>
    <tr>
      <th>35067</th>
      <td>5092284</td>
      <td>또 봐도 재밌네요 ㅋ2편은 평점이거지네요;;</td>
      <td>1</td>
    </tr>
    <tr>
      <th>34590</th>
      <td>4501201</td>
      <td>완전유치뽕짝저질삼류영화..티비편이 훨씬낫다...</td>
      <td>0</td>
    </tr>
    <tr>
      <th>16668</th>
      <td>8848074</td>
      <td>이건 보는 영화가 아니다.</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12196</th>
      <td>178689</td>
      <td>오랜만에 접한 수작...30대 중반 이상분들에게 추천!</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-3cf8f976-09aa-404c-bf52-910d07330808')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-3cf8f976-09aa-404c-bf52-910d07330808 button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-3cf8f976-09aa-404c-bf52-910d07330808');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>





```python
sample_text = ['이 영화는 정말 짜증나서 못 보겠다']
# sample_text = ['오랜만에 접한 수작']
sample_seq = tokenizer.texts_to_sequences(sample_text)
sample_padded = pad_sequences(sample_seq, maxlen=max_length, padding='post')
sample_padded
```




    array([[ 2,  1, 21,  1, 49,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0]],
          dtype=int32)




```python
model.predict([sample_padded])
```




    array([[0.00045144]], dtype=float32)




```python
['positive' if model.predict([sample_padded]) >= 0.5 else 'negative']
```




    ['negative']




```python
model.layers
```




    [<keras.layers.embeddings.Embedding at 0x7fbd970c7f50>,
     <keras.layers.wrappers.Bidirectional at 0x7fbd00cb7310>,
     <keras.layers.core.dense.Dense at 0x7fbcf9fb5e50>,
     <keras.layers.core.dense.Dense at 0x7fbcf9f52bd0>]



## Embedding Layer 시각화

- Embedding projector https://projector.tensorflow.org/  를 이용하여 word embedding 시각화


```python
e = model.layers[0]
weights = e.get_weights()[0]
print(weights.shape)
```

    (20001, 64)
    

### embedding layer 의 weight 를 disk 에 write. Embedding projector 사용을 위해 embedding vector file 과 단어가 들어 있는 meta data file 로 구분하여 upload.


```python
out_v = open('vects.tsv', 'w', encoding='utf-8')
out_m = open('meta.tsv', 'w', encoding='utf-8')

for i in range(1, 1000):
    word = tokenizer.index_word.get(i, '?')
    embeddings = weights[i]
    out_m.write(word + '\n')
    out_v.write('\t'.join([str(x) for x in embeddings]) + '\n')
    
out_v.close()
out_m.close()
```

## Embedding 결과 확인

[Embedding Projector](https://projector.tensorflow.org) 에 접속하여 embedding 의 품질 확인

Google Colab 의 경우 local PC 로 download 받아 Embedding Projector 에 upload


```python

```
